import {sequelize, DataTypes} from "./model.js"

const User = sequelize.define('user', {
   nama: DataTypes.STRING,
   password: DataTypes.STRING,         
})

export default User;