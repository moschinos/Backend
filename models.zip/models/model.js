import {Sequelize, DataTypes} from 'sequelize';

const sequelize = new Sequelize("xyz", "root", "bapakkau", {
   host: 'localhost',
   dialect: 'mysql'
})

export {sequelize, DataTypes}